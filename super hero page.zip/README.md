# SuperHero Hunter

Name: Ashish Jha

Linkedin: https://www.linkedin.com/in/ashish-jha5689/
Regards
Hosted Link: https://ashish5689.github.io/Superhero-Hunter/

## Problem statement
Create a superhero hunter app. Use ONLY vanilla javascript, no libraries or frameworks allowed for Javascript (you can use any css framework like Bootstrap).


## Features

- Home Page
  - Search any superhero from the API and display the search results on the frontend.
  - Each search result of the superhero have a favourite button, clicking on which the superhero is added to “Favourite SuperHeroes”.
  - On clicking any particular superhero, opens a new page with more information about that SuperHero.

- Superhero Page
  - Show a lot of information about the SuperHero like their name, photo, powerstats, bio, etc.

- My favourite superheroes Page
  - A list of all the favourite superheroes.
  - Remove from favourites button: Each superhero have remove from favourites button, clicking on which should remove that superhero from the list.
  




